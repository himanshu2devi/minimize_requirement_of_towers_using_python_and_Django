from xml.dom.minidom import Document
from django import views
from django.contrib import admin
from django.urls import path
from .views import download, home,upload
from django.conf.urls.static import static
from django.conf import settings
from django.views.generic import TemplateView


urlpatterns = [
    path('',home),
    path('upload/',upload),
    path('download/',download)
] +static(settings.MEDIA_URL,Document_root=settings.MEDIA_ROOT)
