from ast import Str
from django.shortcuts import render,HttpResponse
from numpy import sort
import pandas as pd
import numpy as np
from django.core.files import File
from django.http import StreamingHttpResponse
from django.db import connection
from math import radians, cos, sin, asin, acos, sqrt, pi
from geopy import distance
from geopy.geocoders import Nominatim
# import osmnx as ox
import networkx as nx
import math
from csv import writer

from wsgiref.util import FileWrapper
import mimetypes
import os
# Create your views here.

def home(request):
    # if request.method == 'GET':

    #     return render(request, "index.html")

    if request.method == "POST":
        is_private = request.POST.get('is_private', False)
        file1=request.FILES["customerdata"]
        file2=request.FILES["towerdata"]
        
        df=pd.read_csv(file1)
        df2=pd.read_csv(file2)
        # print(df.head())
        
        # df.drop_duplicates(subset="Cust_lat", keep='last', inplace=True)
        # df.drop_duplicates(subset="Cust_long", keep='last', inplace=True)
        # print(df.head())
        R = 6370
        radius = 6371 
        for Customers, Cust_lat ,Cust_long in zip(df['Customers'], df['Cust_lat'],df['Cust_long']):
            for Towers,Latitude,Longitude in zip(df2['Towers'],df2['Latitude'],df2['Longitude']):
                # tmp = pd.DataFrame({'customers': df['Customers'],'Towers': df2['Towers']})
                
                # lat1 = radians(Cust_lat)  #insert value
                # lon1 = radians(Cust_long)
                # lat2 = radians(Longitude)
                # lon2 = radians(Latitude)

                # dlon = lon2 - lon1
                # dlat = lat2- lat1

                # a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
                # c = 2 * math.atan2(sqrt(a), sqrt(1-a))
                # distance = R * c
                # distance1=distance/1000
                # print(distance)
                # print(distance1)
                

                d_lat = np.radians(Cust_lat - Latitude)
                d_lon = np.radians(Cust_long - Longitude)
                a = (np.sin(d_lat / 2.) * np.sin(d_lat / 2.) +
                    np.cos(np.radians(Cust_lat)) * np.cos(np.radians(Latitude)) *
                    np.sin(d_lon / 2.) * np.sin(d_lon / 2.))
                c = 2. * np.arctan2(np.sqrt(a), np.sqrt(1. - a))
                distance = radius * c
                distance1=distance/1000
                # print(distance1)

                if(distance1 <= 4):
                    print(Customers,Towers)
                    # s1 = pd.Series(Customers)
                    # s2 = pd.Series(Towers)
                    # processeddata = pd.concat([s1, s2], axis=1)
                    # processeddata = processeddata.append(processeddata)
                    processeddata=(Customers+","+Towers)
                    processeddata=processeddata.split(',')
                    # print(processeddata)
                    
                    with open("C:\\Users\\HIMANSHU\Desktop\\towercustomer\\toweercustomer\\media\\files\\processed_data.csv", 'a+', newline='') as write_obj:
                        # Create a writer object from csv module
                        csv_writer = writer(write_obj)
                        # Add contents of list as last row in the csv file
                        csv_writer.writerow(processeddata)
                    
                    
                

                

        
        
        df3=pd.read_csv("C:\\Users\\HIMANSHU\Desktop\\towercustomer\\toweercustomer\\media\\files\\processed_data.csv")
        # processeddata.to_csv("C:\\Users\\HIMANSHU\Desktop\\towercustomer\\toweercustomer\\media\\files\\processed_data.csv",index=False)
        df3.drop_duplicates(subset="Customers", keep='first', inplace=True)
        df3.to_csv("C:\\Users\\HIMANSHU\Desktop\\towercustomer\\toweercustomer\\media\\files\\processed_data_with_minimal_towers.csv",index=False)
        return render(request,"index.html",{"something":True})
    else:
        return render(request,"index.html")

def upload(request):
    return render(request,"fileupload.html")


def download(request):
    base_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    filename='processed_data_with_minimal_towers.csv'
    filepath = base_dir + '/media/files/' + filename
    thefile=filepath
    filename=os.path.basename(thefile)
    chunk_size=8192
    response = StreamingHttpResponse(FileWrapper(open(thefile,'rb'),chunk_size),
    content_type=mimetypes.guess_type(thefile)[0])
    response['Content-Length'] = os.path.getsize(thefile)
    response['Content-Disposition']="Attachment;filename=%s" % filename
    return response
